const Usuario = require("../models/usuario");
const ejemplar = require("../models/ejemplar");
const usuario = require("../models/usuario");
const prestamo = require("../models/prestamo");
const documento = require("../models/documento");


const resolvers = {
    Query: {
        async getUsuarios(obj) {
            const usuarios = await Usuario.find();
            return usuarios;
        },
        async getUsuario(obj, { id }) {
            const usuario = await Usuario.findById(id);
            return usuario;
        },
        hello: () => "hola mundo"
    },
    Mutation: {
        async addUsuario(obj, { input }) {
            const usuario = new Usuario(input);
            await usuario.save();
            return usuario;
        },
        async updateUsuario(obj, { id, input }) {
            const usuario = await Usuario.findByIdandUpdate(id, input);
            return usuario;
        },
        async deleteUsuario(obj, { id }) {
            await Usuario.deleteOne({ _id: id });
            return {
                message: "Usuario Eliminado"
            }
        }
    }
}


//reemplazo de Usuario a usuarios?




/* const resolvers = {

    Query: {
        hello: () => "hola mundo",
    },
};
 */
module.exports = { resolvers };