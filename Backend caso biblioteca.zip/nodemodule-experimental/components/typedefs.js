const { gql } = require("apollo-server-express");

// Calling models collections
const Usuario = require("../models/usuario");
const ejemplar = require("../models/ejemplar");
const usuario = require("../models/usuario");
const prestamo = require("../models/prestamo");
const documento = require("../models/documento");


const typeDefs = gql`
    type Usuario{
        id: ID
        email: String
        pass: String
        rut: String
        nombres: String
        direccion: String
        telefono: Int
        activo: Boolean
        admin: Boolean
    }
    type Alert{
        message: String
    }
    input UsuarioInput {
        id: ID
        email: String
        pass: String
        rut: String
        nombres: String
        direccion: String
        telefono: Int
        activo: Boolean
        admin: Boolean
    }

    type Query{
        getUsuarios: [Usuario]
        getUsuario(id: ID) : Usuario
    }
    type Query{
        hello: String
    }

    type Mutation {
        addUsuario(input: UsuarioInput): Usuario
        updateUsuario(id: ID, input:UsuarioInput): Usuario
        deleteUsuario(id:ID) : Alert
    }

`;

module.exports = typeDefs;