const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const { ApolloServer, gql } = require('apollo-server-express');

//const { graphqlExpress, graphiqlExpress } = require('graphql-server-express');
//const { makeExecutableSchema } = require('graphql-tools');

const typeDefs = require('./components/typedefs');
const { resolvers } = require('./components/resolvers');

try {
    mongoose.connect('mongodb+srv://clemente:2169357cs@cluster0.qm3yju4.mongodb.net/estacioncentral', { useNewUrlParser: true, useUnifiedTopology: true });
    
} catch (error) {
    console.log(error)
}





let apolloServer = null;

const corsOptions = {
    origin: "http://localhost:8090",
    credentials: false
};

async function startServer() {
    const apolloServer = new ApolloServer({ typeDefs, resolvers, corsOptions });
    await apolloServer.start();
    apolloServer.applyMiddleware({ app, cors: false });
    app.get("*", (req, res) => res.status(404).send('Not Found'));//eliminar si hay 404 en cualquier archivo existente
}


startServer();

const app = express();
app.use(cors());
const port = process.env.PORT || 8090;
app.listen(port, () => console.log(`Servido iniciado en puerto ${port}`));
/* app.listen(port, function () {
    console.log("Servidor Iniciado en puerto ${origin} ");
}) */;