# Libreria Estacion Central

    npm install   

    nodemon server.js   

    localhost:3000    

Descargar Xampp

iniciar Apache y Mysql

Crear Database de cero(usar mismo nombre)

Importar archivo
