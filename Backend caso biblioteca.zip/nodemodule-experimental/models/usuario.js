const mongoose = require('mongoose');
const usuarioSchema = new mongoose.Schema({
    email: {
        type: String,

    },
    pass: {
        type: String,

    },
    rut: {
        type: String,

    },
    nombres: {
        type: String,

    },
    direccion: {
        type: String,

    },
    telefono: {
        type: Number,

    },
    activo: {
        type: Boolean,

    },
    admin: Boolean

});
//se puede poner required:true para que sea obligatorio

module.exports = mongoose.model('usuario', usuarioSchema);