const mongoose = require('mongoose');
const prestamoSchema = new mongoose.Schema({
    tipoprestamo: String,
    //idejemplar: Number,
    fechaPrestamo: Date,
    horaprestamo: Date,
    fechadevolucion: Date,
    horadevolucion: Date,
});

const solicitudprestamo = new mongoose.Schema({
    //idsolicitud: Number,
    //idUsuario: Number,
    fechasolicitud: Date,
    horasolicitud: Date
})

const detallesolicitudprestamo = new mongoose.Schema({
    //idsolicitud: Number,
    //idejemplar: Number
})

//module.exports = mongoose.model('prestamo', prestamoSchema);
//module.exports = mongoose.model('prestamo', solicitudprestamo);
//module.exports = mongoose.model('prestamo', detallesolicitudprestamo);

const tipoprestamoSchema = mongoose.model('tipoprestamo', prestamoSchema);
const solicitudprestamoSchema = mongoose.model('solicitudprestamo', solicitudprestamo);
const detallesolicitudprestamoSchema = mongoose.model('detalleprestamo', detallesolicitudprestamo);
module.exports = { tipoprestamo: tipoprestamoSchema, solicitudprestamo: solicitudprestamoSchema, detallesolicitudprestamo: detallesolicitudprestamoSchema };