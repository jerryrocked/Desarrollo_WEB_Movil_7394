const mongoose = require('mongoose');

const documentoSchema = new mongoose.Schema({
    tipo: String,
    titulo: String,
    autor: String,
    editorial: String,
    annio: Number,
    edicion: Number,
    categoria: String,
    tipomedio: String
})

module.exports = mongoose.model('documento', documentoSchema);
