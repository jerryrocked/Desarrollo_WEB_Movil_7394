const mongoose = require('mongoose');
const ejemplarSchema = new mongoose.Schema({
    //idejemplar: Number,
    //idDocumento: String,
    estado: Boolean,
    ubicacion: String
});

module.exports = mongoose.model('ejemplar', ejemplarSchema);